(function(){var d=document;d.documentElement.classList.add('js');
d.querySelectorAll('.gallery .ph').forEach(function(el,i){el.style.transitionDelay=(i*150)+'ms'});
d.querySelectorAll('.skills .sk').forEach(function(el,i){el.style.transitionDelay=((i%8)*70)+'ms'});
var t=d.querySelectorAll('section:not(.hero)>*:not(.social):not(.scroll)');
t.forEach(function(el){if(!el.classList.contains('gallery')&&!el.classList.contains('skills'))el.classList.add('rv')});
if(!('IntersectionObserver' in window)){t.forEach(function(el){el.classList.add('in')});return}
var o=new IntersectionObserver(function(es){es.forEach(function(x){if(x.isIntersecting){x.target.classList.add('in');o.unobserve(x.target)}})},{threshold:.12});
t.forEach(function(el){o.observe(el)});})();

(function(){var d=document,rm=matchMedia('(prefers-reduced-motion:reduce)').matches;
var g=d.querySelector('.glow');if(g){addEventListener('mousemove',function(e){g.style.opacity=1;g.style.transform='translate('+e.clientX+'px,'+e.clientY+'px)'})}
d.querySelectorAll('.vid').forEach(function(v){var m=v.querySelector('video');if(!m)return;m.addEventListener('loadeddata',function(){v.classList.add('on')});v.addEventListener('mouseenter',function(){m.play().catch(function(){})});v.addEventListener('mouseleave',function(){m.pause()});v.addEventListener('click',function(){if(m.paused){m.play().catch(function(){})}else{m.pause()}})});
var ba=d.querySelector('.ba');if(ba){var r=ba.querySelector('input');r.addEventListener('input',function(){ba.style.setProperty('--p',r.value+'%')})}
var c=d.getElementById('dust');if(c&&!rm){var x=c.getContext('2d'),W=0,H=0,P=[];var rs=function(){W=c.width=innerWidth;H=c.height=innerHeight};rs();addEventListener('resize',rs);for(var i=0;i<45;i++){P.push({x:Math.random()*W,y:Math.random()*H,r:Math.random()*1.4+.3,s:Math.random()*.25+.05,a:Math.random()*.4+.1})}
var f=function(){x.clearRect(0,0,W,H);P.forEach(function(p){p.y-=p.s;p.x+=Math.sin(p.y/60)*.15;if(p.y<-5){p.y=H+5;p.x=Math.random()*W}x.fillStyle='rgba(255,255,255,'+p.a+')';x.beginPath();x.arc(p.x,p.y,p.r,0,6.283);x.fill()});requestAnimationFrame(f)};f()}
})();

function sendIG(e){
e.preventDefault();
var f=e.target,v=f.querySelectorAll('input,textarea'),n=v[0].value.trim(),p=v[1].value.trim(),m=v[2].value.trim(),t=v[3].value.trim(),s=document.getElementById('st'),u='https://www.instagram.com/kuze_edits_999/';
if(!n||!t){s.textContent='Please enter your name and message.';return}
var txt='Name: '+n+'\nPhone: '+p+'\nE-mail: '+m+'\nMessage: '+t;
var ta=document.createElement('textarea');ta.value=txt;document.body.appendChild(ta);ta.select();
try{document.execCommand('copy')}catch(x){}
ta.remove();
if(navigator.clipboard){navigator.clipboard.writeText(txt).catch(function(){})}
var w=window.open(u,'_blank');
s.innerHTML='Your message is copied. On my Instagram profile tap Message, paste it and press send. '+(w?'':'<a href="'+u+'" target="_blank" rel="noopener">Open Instagram</a>');
f.querySelector('.btn').textContent='Opening Instagram…';
}